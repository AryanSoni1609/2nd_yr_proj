// E:\DBS_PROJECT\jsapps\src\config.js
// Replaces the previous MongoDB/Mongoose configuration

const oracledb = require('oracledb');

// --- IMPORTANT: Replace with your actual Oracle DB details ---
// These should match the username, password, and connection details
// you use to connect via SQL*Plus or SQL Developer.
const dbConfig = {
    user: "system",     // e.g., 'SYSTEM' or a specific user you created
    password: "student", // The password for that Oracle user
    connectString: "localhost:1521/XE" // Common default for Oracle XE.
                                       // Check your Oracle setup. Other possibilities:
                                       // 'localhost:1521/XEPDB1' (Pluggable DB in newer XE)
                                       // 'your_hostname:your_port/your_service_name' for other setups
};
// -------------------------------------------------------------

// Initializes the connection pool
async function initialize() {
    try {
        console.log('Initializing Oracle database module');
        // Create a connection pool which will be managed by node-oracledb
        await oracledb.createPool({
            ...dbConfig,          // Spread the user, password, connectString
            poolAlias: 'default', // Assign an alias to the pool for easy retrieval
            poolIncrement: 1,     // How many connections to increment by if pool runs out
            poolMin: 2,           // Start with 2 connections in the pool
            poolMax: 4            // Allow a maximum of 4 connections
        });
        console.log('Oracle connection pool created successfully');
    } catch (err) {
        // Log the error and exit the application if pool creation fails
        console.error('FATAL: Error creating Oracle connection pool:', err);
        process.exit(1);
    }
}

// Closes the connection pool gracefully
async function closePool() {
    console.log('Closing Oracle connection pool');
    try {
        // Check if the pool exists before trying to close
        if (oracledb.getPool('default')) {
             // Attempt to close the pool, waiting up to 10 seconds for connections to drain
             await oracledb.getPool('default').close(10);
             console.log('Oracle connection pool closed');
        }
    } catch (err) {
        console.error('Error closing Oracle connection pool:', err);
    }
}

// Executes a SQL statement
// Takes the SQL query string, an array of bind variables, and optional execution options
async function simpleExecute(sql, binds = [], opts = {}) {
    let connection;
    let result;
    // Set default options for query results and transaction handling
    opts.outFormat = oracledb.OUT_FORMAT_OBJECT; // Return rows as JavaScript objects
    opts.autoCommit = true; // Automatically commit INSERT, UPDATE, DELETE statements

    try {
        // Get a connection from the default pool
        connection = await oracledb.getConnection('default');
        // Execute the SQL statement with bind variables and options
        result = await connection.execute(sql, binds, opts);
        return result; // Return the execution result (e.g., rows for SELECT)
    } catch (err) {
        // Log errors during execution for easier debugging
        console.error('Error executing SQL:', err);
        console.error('SQL Query:', sql);
        console.error('Bind Variables:', binds);
        throw err; // Re-throw the error so the calling function knows it failed
    } finally {
        // Ensure the connection is always released back to the pool
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error('Error closing Oracle connection:', err);
            }
        }
    }
}

// Export the functions to be used in other parts of the application (like index.js)
module.exports = {
    initialize,    // Function to set up the pool (call this on app start)
    closePool,     // Function to close the pool (call this on app shutdown)
    simpleExecute  // Function to run SQL queries (use this in your route handlers)
};