// E:\DBS_PROJECT\jsapps\src\index.js (Modified with Complex Queries)

const express = require('express');
const path = require('path');
const bcrypt = require('bcrypt');
const db = require('./config'); // Oracle config (initialize, closePool, simpleExecute)

const app = express();

// --- Middleware ---
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// --- View Engine Setup ---
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));
console.log("Views Path:", path.join(__dirname, '../views'));

// --- Static Files ---
app.use(express.static(path.join(__dirname, '../public')));


// --- Basic & Authentication Routes ---

// Route for Login Page
app.get("/", (req, res) => {
    res.render("login");
});

// Route for Signup Page
app.get("/signup", (req, res) => {
    res.render("signup");
});

// Route for Forgot Password Page
app.get("/forgotpassword", (req, res) => {
    res.render("forgotpassword"); // Ensure forgotpassword.ejs exists
});

// Register User (Signup POST) - Uses app_users table
app.post("/signup", async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) {
            return res.status(400).send("Username and password are required.");
        }
        const checkUserSql = `SELECT COUNT(*) AS count FROM app_users WHERE username = :1`;
        const checkResult = await db.simpleExecute(checkUserSql, [username]);
        if (checkResult.rows[0].COUNT > 0) {
            return res.send("User already exists. Please choose a different username.");
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const insertSql = `INSERT INTO app_users (username, password_hash) VALUES (:u, :p)`;
        await db.simpleExecute(insertSql, { u: username, p: hashedPassword });
        console.log(`User ${username} registered successfully.`);
        res.send("Signup successful! You can now login.");
    } catch (error) {
        console.error("Error signing up:", error);
        res.status(500).send("An error occurred during signup. Please try again later.");
    }
});

// Login User (Login POST) - Uses app_users table
app.post("/login", async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) {
            return res.status(400).send("Username and password are required.");
        }
        const findUserSql = `SELECT password_hash FROM app_users WHERE username = :1`;
        const result = await db.simpleExecute(findUserSql, [username]);
        if (!result.rows || result.rows.length === 0) {
            return res.send("Username not found");
        }
        const storedHash = result.rows[0].PASSWORD_HASH; // Oracle returns uppercase
        if (!storedHash) {
            console.error(`Password hash not found for user: ${username}`);
            return res.status(500).send("An error occurred during login.");
        }
        const isPasswordMatch = await bcrypt.compare(password, storedHash);
        if (isPasswordMatch) {
            console.log(`User ${username} logged in successfully.`);
            // In a real app: establish session/token
            res.render("home"); // Render home page on successful login
        } else {
            res.send("Wrong password");
        }
    } catch (error) {
        console.error("Error logging in:", error);
        res.status(500).send("An error occurred during login. Please try again later.");
    }
});


// --- Blood Bank Feature Routes (Examples) ---

// --- Donor Routes ---
app.get("/donors", async (req, res) => {
    try {
        const sql = `
            SELECT 
                d.DonorID, d.Name, d.ContactInfo, d.BloodType, d.Age, d.Weight,
                (SELECT COUNT(*) FROM DonationRecord dr WHERE dr.DonorID = d.DonorID) AS DonationCount
            FROM Donor d
            ORDER BY d.DonorID
        `;
        const result = await db.simpleExecute(sql);
        console.log("Donors with Donation Counts:", result.rows); // Add this line
        res.render("donors_list", { donors: result.rows }); // CREATE views/donors_list.ejs
    } catch (err) {
        console.error("Error fetching donors:", err);
        res.status(500).send("Error retrieving donor list.");
    }
});

app.get("/donors/new", (req, res) => {
    // Pass an empty donor object and action for the form
    res.render("donor_form", { donor: {}, action: '/donors', title: 'Add New Donor', emergencyContactNumber: '' }); // CREATE views/donor_form.ejs
});

app.post("/donors", async (req, res) => {
    const { donorId, name, contactInfo, bloodType, age, weight, emergencyContactNumber } = req.body;
    // ADD validation for input fields
    try {
        const donorSql = `INSERT INTO Donor (DonorID, Name, ContactInfo, BloodType, Age, Weight)
                                            VALUES (:donorId, :name, :contactInfo, :bloodType, :age, :weight)`;
        await db.simpleExecute(donorSql, { donorId, name, contactInfo, bloodType, age, weight });

        if (emergencyContactNumber) {
            const emergencySql = `INSERT INTO EmergencyContact (DonorID, EmergencyContactNumber) VALUES (:donorId, :emergencyContactNumber)`;
            await db.simpleExecute(emergencySql, { donorId, emergencyContactNumber });
        }

        console.log(`Donor ${name} added successfully.`);
        res.redirect("/donors");
    } catch (err) {
        console.error("Error adding donor:", err);
        res.status(500).send("Error adding new donor.");
        // TODO: Re-render form with error message and existing data
    }
});

app.get("/donors/:id", async (req, res) => {
    const donorId = req.params.id;
    try {
        const donorSql = `SELECT * FROM Donor WHERE DonorID = :1`;
        const eligibilitySql = `SELECT * FROM Eligibility WHERE DonorID = :1`;
        const emergencySql = `SELECT EmergencyContactNumber FROM EmergencyContact WHERE DonorID = :1`;

        const donorResult = await db.simpleExecute(donorSql, [donorId]);
        const eligibilityResult = await db.simpleExecute(eligibilitySql, [donorId]);
        const emergencyResult = await db.simpleExecute(emergencySql, [donorId]);

        if (donorResult.rows.length === 0) {
            return res.status(404).send("Donor not found.");
        }
        res.render("donor_detail", { // CREATE views/donor_detail.ejs
            donor: donorResult.rows[0],
            eligibility: eligibilityResult.rows.length > 0 ? eligibilityResult.rows[0] : null,
            emergencyContacts: emergencyResult.rows // This will be an array of objects
        });
    } catch (err) {
        console.error(`Error fetching donor ${donorId}:`, err);
        res.status(500).send("Error retrieving donor details.");
    }
});

app.get("/donors/:id/edit", async (req, res) => {
    const donorId = req.params.id;
    try {
        const donorSql = `SELECT * FROM Donor WHERE DonorID = :1`;
        const emergencySql = `SELECT EmergencyContactNumber FROM EmergencyContact WHERE DonorID = :1`;

        const donorResult = await db.simpleExecute(donorSql, [donorId]);
        const emergencyResult = await db.simpleExecute(emergencySql, [donorId]);

        if (donorResult.rows.length === 0) {
            return res.status(404).send("Donor not found.");
        }

        const emergencyContactNumber = emergencyResult.rows.length > 0 ? emergencyResult.rows[0].EMERGENCYCONTACTNUMBER : '';

        res.render("donor_form", {
            donor: donorResult.rows[0],
            action: `/donors/${donorId}`, // Update action
            title: 'Edit Donor',
            emergencyContactNumber: emergencyContactNumber
        });
    } catch (err) {
        console.error(`Error fetching donor ${donorId}:`, err);
        res.status(500).send("Error retrieving donor details.");
    }
});

app.post("/donors/:id", async (req, res) => {
    const donorId = req.params.id;
    const { name, contactInfo, bloodType, age, weight, emergencyContactNumber } = req.body;
    try {
        const donorSql = `UPDATE Donor SET Name = :name, ContactInfo = :contactInfo, BloodType = :bloodType, Age = :age, Weight = :weight WHERE DonorID = :donorId`;
        await db.simpleExecute(donorSql, { donorId, name, contactInfo, bloodType, age, weight });

        const emergencySql = `UPDATE EmergencyContact SET EmergencyContactNumber = :emergencyContactNumber WHERE DonorID = :donorId`;

        if (emergencyContactNumber) {
            const emergencyCheckSql = `SELECT count(*) as count FROM EmergencyContact WHERE DonorID = :donorId`;
            const emergencyCheckResult = await db.simpleExecute(emergencyCheckSql, {donorId});
            if (emergencyCheckResult.rows[0].COUNT > 0) {
                await db.simpleExecute(emergencySql, {donorId, emergencyContactNumber});
            } else {
                const emergencyInsertSql = `INSERT INTO EmergencyContact (DonorID, EmergencyContactNumber) VALUES (:donorId, :emergencyContactNumber)`;
                await db.simpleExecute(emergencyInsertSql, {donorId, emergencyContactNumber});
            }

        }

        res.redirect(`/donors/${donorId}`);
    } catch (err) {
        console.error(`Error updating donor ${donorId}:`, err);
        res.status(500).send("Error updating donor.");
    }
});

// --- Camp Routes ---
app.get("/camps", async (req, res) => {
    try {
        const sql = `
            SELECT 
                cs.CampID, cs.CampDate, cs.Location,
                (SELECT COUNT(*) FROM DonationRecord dr WHERE dr.CampID = cs.CampID) AS DonationCount
            FROM CampScheduling cs
            ORDER BY cs.CampDate DESC
        `;
        const result = await db.simpleExecute(sql);
        res.render("camps_list", { camps: result.rows }); // CREATE views/camps_list.ejs
    } catch (err) {
        console.error("Error fetching camps:", err);
        res.status(500).send("Error retrieving camp list.");
    }
});
// TODO: Add full CRUD routes for Camps (GET /camps/new, POST /camps, GET /camps/:id, etc.)

// --- Inventory Routes ---
app.get("/inventory", async (req, res) => {
    try {
        const sql = `
            SELECT inv.InventoryID, inv.BloodType, inv.UnitsAvailable, adm.Name AS AdminName
            FROM InventoryManagement inv
            LEFT JOIN Admin adm ON inv.AdminID = adm.AdminID
            ORDER BY inv.BloodType
        `;
        const result = await db.simpleExecute(sql);
        res.render("inventory_list", { inventory: result.rows }); // CREATE views/inventory_list.ejs
    } catch (err) {
        console.error("Error fetching inventory:", err);
        res.status(500).send("Error retrieving inventory list.");
    }
});
// TODO: Add routes for updating inventory if required

// --- Donation Record Routes ---
app.get("/donations", async (req, res) => {
    try {
        const sql = `
            SELECT
                dr.DonorID, d.Name AS DonorName, dr.DonationDate,
                dr.Volume, dr.CampID, cs.Location AS CampLocation
            FROM DonationRecord dr
            JOIN Donor d ON dr.DonorID = d.DonorID
            JOIN CampScheduling cs ON dr.CampID = cs.CampID
            ORDER BY dr.DonationDate DESC
        `;
        const result = await db.simpleExecute(sql);
        res.render("donations_list", { donations: result.rows }); // CREATE views/donations_list.ejs
    } catch (err) {
        console.error("Error fetching donation records:", err);
        res.status(500).send("Error retrieving donation records.");
    }
});
// TODO: Add routes for adding donation records if required

app.get("/donations/new", async (req, res) => {
    try {
        // Fetch donors and camps for dropdowns in the form
        const donors = await db.simpleExecute("SELECT DonorID, Name FROM Donor");
        const camps = await db.simpleExecute("SELECT CampID, Location FROM CampScheduling");
        res.render("donation_form", { donors: donors.rows, camps: camps.rows }); // Create donation_form.ejs
    } catch (err) {
        console.error("Error fetching donors or camps:", err);
        res.status(500).send("Error loading donation form.");
    }
});

app.post("/donations", async (req, res) => {
    const { donorId, campId, donationDate, volume } = req.body;
    try {
        const sql = `
            INSERT INTO DonationRecord (DonorID, CampID, DonationDate, Volume)
            VALUES (:donorId, :campId, TO_DATE(:donationDate, 'YYYY-MM-DD'), :volume)
        `;
        await db.simpleExecute(sql, { donorId, campId, donationDate, volume });
        res.redirect("/donations");
    } catch (err) {
        console.error("Error adding donation:", err);
        res.status(500).send("Error adding donation record.");
    }
});

app.get("/donationLogs", async (req, res) => {
    try {
        const sql = "SELECT * FROM DonationLog ORDER BY LogTimestamp DESC"; // Fetch log data
        const result = await db.simpleExecute(sql);
        res.render("donation_logs", { logs: result.rows }); // Create donation_logs.ejs
    } catch (err) {
        console.error("Error fetching donation logs:", err);
        res.status(500).send("Error retrieving donation logs.");
    }
});

// --- Server Startup and Graceful Shutdown (Keep this at the end) ---

async function startup() {
    console.log('Starting application...');
    try {
        console.log('Initializing database connection pool...');
        await db.initialize(); // Initialize the Oracle DB pool from config.js
        const port = 5000;
        app.listen(port, () => {
            console.log(`Server running on Port: ${port}`);
        });
    } catch (err) {
        console.error('Application startup error:', err);
        process.exit(1);
    }
}

async function shutdown(signal) {
    console.log(`${signal} signal received: closing application...`);
    try {
        await db.closePool(); // Close the Oracle DB pool from config.js
        console.log('Database pool closed. Exiting.');
        process.exit(0);
    } catch (err) {
        console.error('Error during shutdown:', err);
        process.exit(1);
    }
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

startup(); // Start the application